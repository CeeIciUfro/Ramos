package funciones;

import java.util.*;

public class Ejemplo {

    public static void ingresarVentas(int[][] mat, Scanner z) {
        Random azar = new Random();
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length - 1; j++) {
                mat[i][j] = azar.nextInt(100)+1;
                /*do {
                    System.out.print("Ingrese producto " + (i + 1)
                            + " en la semana " + (j + 1) + ": ");
                    mat[i][j] = z.nextInt();
                } while (mat[i][j] <= 0 || mat[i][j] > 100);*/
                
            }
        }
    }

    public static void main(String[] args) {
        int i;
        int ventas[][] = new int[10][5];
        Scanner leer = new Scanner(System.in);
        ingresarVentas(ventas, leer);
        for (i = 0; i < 10; i++) {
            asignarExtra(ventas, i, calculaTotal(ventas, i));
        }
        mostrarResumen(ventas);
        System.out.println("El articulo con mayor estimacion es:"
                + articuloMayorEstimacion(ventas));
    }

    public static int calculaTotal(int m[][], int x) {
         return m[x][0]+m[x][1]+m[x][2] +m[x][3];
         /*
         int suma = 0;
         for(int=0; i<m[x].length-1;i++)
           suma = suma + m[x][i]; //suma +=m[x][i];
         return suma;
         */
    }

    public static void asignarExtra(int datos[][], int f, int m) {
        if (m < 200)
            m = m + 10;
        else
            m = m + 20;
        datos[f][4] = m;
    }

    public static void mostrarResumen(int v[][]) {
        for (int i = 0; i < v.length; i++) {
            System.out.print((i + 1) + "  ");
            for (int j = 0; j < v[i].length; j++) {
                System.out.print(v[i][j] + "  ");
            }
            System.out.println();
        }
    }

    public static int articuloMayorEstimacion(int[][] x) {
       int max =0, producto=0;
       for(int i=0; i < x.length; i++){
           if(max < x[i][4]){
               max = x[i][4];
               producto = i;
           }
       }
       return producto + 1;
    }
}
