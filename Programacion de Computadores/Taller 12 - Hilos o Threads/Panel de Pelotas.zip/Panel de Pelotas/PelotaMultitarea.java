
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;

//
public class PelotaMultitarea extends JFrame
{
   private PanelPelota dibujarPanel;
// Un vector es similar a un array, 
// la diferencia estriba en que un vector crece automáticamente 
// cuando alcanza la dimensión inicial máxima. Además, 
// proporciona métodos adicionales para añadir, eliminar elementos, 
// e insertar elementos entre otros dos existentes.
   private Vector<Pelota> ArrayPelotas;
   private JTextField mensaje;

   // set up interface
   public PelotaMultitarea()  
   {
      super("Ejemplo Multitarea");
      dibujarPanel = new PanelPelota(400, 345); // define un nuevo panel del tamaño de la ventana
      mensaje = new JTextField();
      mensaje.setEditable(false);
     
      ArrayPelotas = new Vector<Pelota>();
      add(dibujarPanel, BorderLayout.NORTH);
      add(mensaje, BorderLayout.SOUTH);
      setSize(400, 400);
      setVisible(true);
   } 

   // la clase Pelota es usada para crear una pelota y mover
   // el método run() del hilo de ejecución define como se mueve
   // cada nueva pelota en particular
 
   private class Pelota extends Thread
   {
      
      private Ellipse2D.Double nuevaPelota; // para dibujar la pelota
      private boolean pelotaStart; // para controlar la ejecución del hilo
      private int diametro, velocidad;  // propiedades de la pelota
      private int deltax, deltay;          // variacion de movimiento de la pelota
  
      public Pelota()
      {
         // crea una nueva pelota con sus propiedades con valores aleatorios
         // 
         pelotaStart = true;   
         diametro = 10 + (int)(Math.random() * 60);
         velocidad = 10 + (int)(Math.random() * 100);
         int startx = (int)(Math.random() * 300);
         int starty = (int)(Math.random() * 300);
         deltax = -10 + (int)(Math.random() * 21);
         deltay = -10 + (int)(Math.random() * 21);
         if ((deltax == 0) && (deltay == 0)) { deltax = 1; }
         // crea el dibujo d ela pelota con los valores definidos
         nuevaPelota = new Ellipse2D.Double(startx, starty, diametro, diametro);
      }

      
      public void draw(Graphics2D g2d)
      {
         if (nuevaPelota != null)
         {
             // define el color y pinta de la pelota 
            g2d.setColor(Color.BLUE);
            g2d.fill(nuevaPelota);
         }
      }
// ejecución  para cada nueva pelota
      public void run()
      {
         while(pelotaStart)   // para mantener la peolota en movimiento
         {
           try {
               // define la velocidad del proceos del hilo= velocidad de la pelota
               Thread.sleep(velocidad);
            }
            catch (InterruptedException e)
            {  System.out.println("Error");}

            // define una nueva posición para mover la pelota 
            int oldx = (int) nuevaPelota.getX();
            int oldy = (int) nuevaPelota.getY();
            int newx = oldx + deltax; //suma a la posición el delta definido
            if (newx + diametro > dibujarPanel.getWidth() || newx < 0) 
               deltax = -deltax;
            int newy = oldy + deltay;
            if (newy + diametro > dibujarPanel.getHeight() || newy < 0) 
               deltay = -deltay;            
            nuevaPelota.setFrame(newx, newy, diametro, diametro);
            //borra y pinta la pelota nuevamente
            dibujarPanel.repaint();
         }
      }
   } // fin de la clase Pelota


   // Define una clase con el Panel para contender
   // el conjunto de pelotas generadas
   private class PanelPelota extends JPanel  {
      private int ancho, alto;
 
      public PanelPelota (int an, int al)
      {
         ancho = an;
         alto = al;
         // gestiona los posibles eventos del mouse
         addMouseListener(

		new MouseAdapter()  {
		// en el caso de un clic del mouse sobre el panel contendio en la pantalla
		   public void mouseClicked(MouseEvent e)
                   {
                       Pelota nuevaPelota = new Pelota(); // crea nuevo hilo con una nueva pelota
                       ArrayPelotas.addElement(nuevaPelota); // agrega la nueva pelota al vector = conjunto de elementos
                       mensaje.setText("antes de crear " + ArrayPelotas.size());
                       nuevaPelota.start(); //incia la ejecucíon del nuevo hilo
                       mensaje.setText("Cantidad de Pelotas: " + ArrayPelotas.size()); //mensaje con la cantidad de pelotas
                      
                   }
                }
          );
      }

      public Dimension getPreferredSize()
      {
         return new Dimension(ancho, alto);
      }

      public void paintComponent (Graphics g)  
      {
          super.paintComponent(g);
          Graphics2D g2d = (Graphics2D) g;
          for (int i = 0; i < ArrayPelotas.size(); i++) 
          { 
             (ArrayPelotas.elementAt(i)).draw(g2d);
          }
      }
   } // fin clase 
} 
           