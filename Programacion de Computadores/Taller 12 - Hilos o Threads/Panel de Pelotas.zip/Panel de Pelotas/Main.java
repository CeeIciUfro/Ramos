import java.awt.event.*;
public class Main
{
   
    public Main()
    {
       
    }

   // método principal para ejecutar, crea una nueva ventana 

   public static void main(String args[])  {

      PelotaMultitarea application = new PelotaMultitarea();
      // para manejar los eventos de la ventana principal de la aplicación
      application.addWindowListener(
         new WindowAdapter()
         {
            // si se hace clic en cerrar ventana 
            public void windowClosing(WindowEvent e)  
            {
               System.exit(0);
            }
         }
      );
   } // 
}
