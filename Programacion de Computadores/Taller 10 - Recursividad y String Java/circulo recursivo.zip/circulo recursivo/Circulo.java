import java.awt.geom.*; //paquete gráfico para dibujar elipse
public class Circulo
{
    private int width;
    private int xPosition;
    private int yPosition;
    private String color;
    
    public Circulo ()
    {
      width = 400;
      xPosition = 500;
      yPosition = 150;
      color="blue";
    }   

   public void main()
    {
        
       for (int i=10;i<100;i=i+10){   
       this.makeVisibleRecursive(this.width+i,xPosition+i,yPosition+i);  
    }
       
    }
    
// dibuja de forma recursiva
     public void makeVisibleRecursive(int w, int x, int y)
    {
            if (w==0 || x==0 || y==0){ return;}
            else{
            Canvas canvas = Canvas.getCanvas();// crea un frame gráfico 
            canvas.draw(this, color, new Ellipse2D.Double(x, y, w, w)); // dibuja la elipse = circulo
            canvas.wait(2); // espera 
            makeVisibleRecursive(w-1, x-1, y-1); // se llama a si mismo de forma recursiva
    }
    
}
}

    
  